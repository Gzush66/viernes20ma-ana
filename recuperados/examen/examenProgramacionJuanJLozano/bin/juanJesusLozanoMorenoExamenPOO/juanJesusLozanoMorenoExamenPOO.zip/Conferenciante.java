package juanJesusLozanoMorenoExamenPOO;

public interface Conferenciante {

	void charlar();
}
