package juanJesusLozanoMorenoExamenPOO;

public class Emerito extends Profesor implements Conferenciante{
	private String nombre;
	private String dni;
	private float salario;
	

	Emerito(String nombre,String dni,float salario,Asignatura codigo,Asignatura titulo) {
		super(nombre, dni, salario,codigo,titulo);
		
	}
	public String getNombre () {
		return nombre;
	}
	public String getDni() {
		return dni;
	}
	public float getSalario() {
		return salario;
	}
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	public void setDni (String dni) {
		this.dni=dni;
	}
	public void setSalario(float salario) {
		this.salario=salario;
	}
	
	@Override
	public void  saludar() {
		System.out.println("Buenos dias");
	}
	@Override
	public void charlar() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
