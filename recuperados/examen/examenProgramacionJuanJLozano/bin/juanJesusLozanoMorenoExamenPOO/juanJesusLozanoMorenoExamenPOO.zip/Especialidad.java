package juanJesusLozanoMorenoExamenPOO;

public enum Especialidad {
	CONTRATO,NOMINA,GESTIONAULA, CURSOEXTRAORDINARIO

}
