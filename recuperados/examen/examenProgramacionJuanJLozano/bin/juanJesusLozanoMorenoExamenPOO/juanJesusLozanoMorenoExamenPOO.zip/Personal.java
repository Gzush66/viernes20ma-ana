package juanJesusLozanoMorenoExamenPOO;

public class Personal extends Persona {

	public String nombre;
	public String dni;
	protected float salario;
	
	

 int salarioMinimo;
 salarioMinimo=10000;
	
	if (salario<10000) {
		salario=salarioMinimo;
	}
	
	Personal(String nombre,String dni,int salario){
		super( nombre,dni);
		//this.nombre=nombre;
		//this.dni=dni;
		this.salario=salario;		
	}
	public String getNombre () {
		return nombre;
	}
	public String getDni() {
		return dni;
	}
	public float getSalario() {
		return salario;
	}
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	public void setDni (String dni) {
		this.dni=dni;
	}
	public void setSalario(float salario) {
		this.salario=salario;
	}
	
	public void  saludar()  {
		System.out.println("Buenos dias");
		
	}
	
	
	
	
	

}
