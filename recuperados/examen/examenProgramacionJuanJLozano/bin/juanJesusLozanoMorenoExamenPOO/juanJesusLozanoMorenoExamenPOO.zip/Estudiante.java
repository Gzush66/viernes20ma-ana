package juanJesusLozanoMorenoExamenPOO;

public class Estudiante {
	
	private String nombre;
	private String dni;
	
	Estudiante(String nombre,String dni){
		super();
	}
	
	
	public String getNombre () {
		return nombre;
	}
	public String getDni() {
		return dni;
	}
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	public void setDni (String dni) {
		this.dni=dni;
	}
	public void  saludar()  {
		System.out.println("Hola");
		
	}
	
	
	

}
